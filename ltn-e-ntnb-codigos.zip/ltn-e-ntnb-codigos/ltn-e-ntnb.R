#install.packages('tidyverse')
#install.packages('GetTDData')
library(tidyverse)
library(GetTDData)

# Funções de conversão  ---------------------------------------------------

bond.discount=function(x, maturity.in.years, input.type = "spot", compounding.frequency = 2, na.rm = F)
{
  if(isTS <- is(x, "seriesVirtual")) {
    oldSer <- x
    x <- seriesData(x)
  }
  if(isDF <- is.data.frame(x)) {
    x <- as.matrix(x)
  }
  isRow <- (!is.null(dx <- dim(x))) && (dx[1] == 1)
  isBig <- is(x, "bdObject")
  if(isBig && is(x, "bdFrame")) {
    if(numCols(x) > 1)
      stop("Only vectors are supported")
    x <- x[, 1, drop = T]
  }
  if(length(maturity.in.years) == 1) {
    if(isBig)
      maturity.in.years <- rep(maturity.in.years, length(x), big = T)
    else maturity.in.years <- rep(maturity.in.years, length(x))
  }
  else if(length(maturity.in.years) != length(x)) {
    stop("x and maturity.in.years must have compatible lengths")
  }
  naIdx <- is.na(x)
  if(any(naIdx)) {
    if(na.rm) {
      naIdx <- !naIdx
      x <- x[naIdx, drop = F]
      maturity.in.years <- maturity.in.years[naIdx]
      if(isTS)
        oldSer <- oldSer[naIdx,  , drop = F]
    }
    else {
      stop("NAs are not allowed when na.rm is FALSE")
    }
  }
  input.type <- casefold(input.type)
  if(input.type == "forward") {
    maturity.in.years <- c(maturity.in.years[1], diff(maturity.in.years))
    if(compounding.frequency == 0) {
      x <- exp( - x * maturity.in.years)
    }
    else {
      x <- (1. + x/compounding.frequency)^( - maturity.in.years * compounding.frequency)
    }
    x <- cumprod(x)
  }
  else if(input.type == "spot") {
    if(compounding.frequency == 0) {
      x <- exp( - x * maturity.in.years)
    }
    else {
      x <- (1. + x/compounding.frequency)^( - maturity.in.years * compounding.frequency)
    }
  }
  else {
    stop("Invalid choice for argument input.type")
  }
  if(isRow && !isBig) {
    x <- matrix(x, nrow = 1)
  }
  if(isTS) {
    if(isBig)
      x <- as.bdFrame(x)
    if(isDF)
      x <- as.data.frame(x)
    seriesData(oldSer) <- x
    x <- oldSer
  }
  x
}


bond.spot=function(x, maturity.in.years, input.type = "discount", compounding.frequency = 2, na.rm = F)
{
  if(isTS <- is(x, "seriesVirtual")) {
    oldSer <- x
    x <- seriesData(x)
  }
  if(isDF <- is.data.frame(x)) {
    x <- as.matrix(x)
  }
  isRow <- (!is.null(dx <- dim(x))) && (dx[1] == 1)
  isBig <- is(x, "bdObject")
  if(isBig && is(x, "bdFrame")) {
    if(numCols(x) > 1)
      stop("Only vectors are supported")
    x <- x[, 1, drop = T]
  }
  if(length(maturity.in.years) == 1) {
    if(isBig)
      maturity.in.years <- rep(maturity.in.years, length(x), big = T)
    else maturity.in.years <- rep(maturity.in.years, length(x))
  }
  else if(length(maturity.in.years) != length(x)) {
    stop("x and maturity.in.years must have compatible lengths")
  }
  naIdx <- is.na(x)
  if(any(naIdx)) {
    if(na.rm) {
      naIdx <- !naIdx
      x <- x[naIdx, drop = F]
      maturity.in.years <- maturity.in.years[naIdx]
      if(isTS)
        oldSer <- oldSer[naIdx,  , drop = F]
    }
    else {
      stop("NAs are not allowed when na.rm is FALSE")
    }
  }
  input.type <- casefold(input.type)
  if(input.type != "forward" && input.type != "discount") {
    stop("Invalid choice for argument input.type")
  }
  if(input.type == "forward") {
    fmaturity.in.years <- c(maturity.in.years[1], diff(maturity.in.years))
    if(compounding.frequency == 0) {
      x <- exp( - x * fmaturity.in.years)
    }
    else {
      x <- (1. + x/compounding.frequency)^( - fmaturity.in.years * compounding.frequency)
    }
    x <- cumprod(x)
  }
  if(compounding.frequency == 0) {
    x <-  - log(x)/maturity.in.years
  }
  else {
    x <- (x^(-1/(compounding.frequency * maturity.in.years)) - 1.) * compounding.frequency
  }
  if(isRow && !isBig) {
    x <- matrix(x, nrow = 1)
  }
  if(isTS) {
    if(isBig)
      x <- as.bdFrame(x)
    if(isDF)
      x <- as.data.frame(x)
    seriesData(oldSer) <- x
    x <- oldSer
  }
  x
}




bond.forward=function(x, maturity.in.years, input.type = "spot", 
                      compounding.frequency = 2, na.rm = F)
{
  if(isTS <- is(x, "seriesVirtual")) {
    oldSer <- x
    x <- seriesData(x)
  }
  if(isDF <- is.data.frame(x)) {
    x <- as.matrix(x)
  }
  isRow <- (!is.null(dx <- dim(x))) && (dx[1] == 1)
  isBig <- is(x, "bdObject")
  if(isBig && is(x, "bdFrame")) {
    if(numCols(x) > 1)
      stop("Only vectors are supported")
    x <- x[, 1, drop = T]
  }
  if(length(maturity.in.years) == 1) {
    if(isBig)
      maturity.in.years <- rep(
        maturity.in.years, length(
          x), big = T)
    else maturity.in.years <- rep(
      maturity.in.years, length(
        x))
  }
  else if(length(maturity.in.years) != length(x)) {
    stop("x and maturity.in.years must have compati
ble lengths"
    )
  }
  naIdx <- is.na(x)
  if(any(naIdx)) {
    if(na.rm) {
      naIdx <- !naIdx
      x <- x[naIdx, drop = F]
      maturity.in.years <- maturity.in.years[
        naIdx]
      if(isTS)
        oldSer <- oldSer[naIdx,  ,
                         drop = F]
    }
    else {
      stop("NAs are not allowed when na.rm is
 FALSE"
      )
    }
  }
  input.type <- casefold(input.type)
  if(input.type != "spot" && input.type != "discount") 
  {
    stop("Invalid choice for argument input.type")
  }
  if(input.type == "spot") {
    if(compounding.frequency == 0) {
      x <- exp( - x * maturity.in.years)
    }
    else {
      x <- (1. + x/compounding.frequency)^
        ( - maturity.in.years * 
            compounding.frequency)
    }
  }
  ans <- x
  if(isBig)
    indx <- seq(1, length(x) - 1, 1, big = T)
  else indx <- 1:(length(x) - 1)
  ans[indx + 1] <- x[indx + 1]/x[indx]
  maturity.in.years <- c(maturity.in.years[1], diff(
    maturity.in.years))
  if(compounding.frequency == 0) {
    ans <-  - log(ans)/maturity.in.years
  }
  else {
    ans <- compounding.frequency * (ans^(-1./
                                           (maturity.in.years * 
                                              compounding.frequency)) - 1)
  }
  if(isRow && !isBig) {
    ans <- matrix(ans, nrow = 1)
  }
  if(isTS) {
    if(isBig)
      ans <- as.bdFrame(ans)
    if(isDF)
      ans <- as.data.frame(ans)
    seriesData(oldSer) <- ans
    ans <- oldSer
  }
  ans
}


# LTN -------------------------------------------------------------------------
#LTN Spot
ltn_df <- td_get(
  asset_codes = "LTN",
  first_year = 2005,
  last_year = as.numeric(format(Sys.Date(), "%Y"))
)


LTN <- ltn_df %>%
  filter(matur_date  >  as.Date('2023-07-15', format = "%Y-%m-%d")) %>% 
  select(yield_bid, matur_date, ref_date) %>% 
  pivot_wider(names_from = matur_date, values_from = yield_bid) %>% 
  select('2024-07-01', '2025-01-01', '2026-01-01', '2029-01-01')

vert_ltn <- c(18, 30, 42, 54)
lambda=.0609
ltnf1=seq(1,1,length=length(vert_ltn))
ltnf2=(1-exp(-lambda*vert_ltn))/(lambda*vert_ltn)
ltnf3=((1-exp(-lambda*vert_ltn))/(lambda*vert_ltn)-exp(-lambda*vert_ltn))

ltndlreg=lm(as.numeric(LTN[1352,])~ltnf1+ltnf2+ltnf3-1)

#plot(vert_ltn,LTN[1352,])
#lines(vert_ltn,fitted(ltndlreg))



#LTN discount

ltndiscount = bond.discount(LTN[1352,], vert_ltn, input.type = "spot", compounding.frequency = 1, na.rm = F)
ltndlreg2 <- lm(as.numeric(ltndiscount)~ltnf1+ltnf2+ltnf3-1)
#plot(vert_ltn,ltndiscount,type="l")

#LTN Foward

ltnforward = bond.forward(LTN[1352,], vert_ltn, input.type = "spot", compounding.frequency = 1, na.rm = F)
ltndlreg3 <- lm(as.numeric(ltnforward)~ltnf1+ltnf2+ltnf3-1)
#plot(vert_ltn,ltnforward,type="l")


# NTN-B -------------------------------------------------------------------------

#NTN-B Spot
ntnb_df <- td_get(
  asset_codes = "NTN-B",
  first_year = 2005,
  last_year = as.numeric(format(Sys.Date(), "%Y"))
)


NTNB <- ntnb_df %>%
  filter(matur_date  >  as.Date('2023-07-15', format = "%Y-%m-%d")) %>% 
  select(yield_bid, matur_date, ref_date) %>% 
  pivot_wider(names_from = matur_date, values_from = yield_bid) %>% 
  select('2024-08-15', '2026-08-15', '2030-08-15', '2032-08-15', '2035-05-15', '2040-08-15', '2045-05-15', '2050-08-15', '2055-05-15')

vert_ntnb <- c(13, 37, 85, 109, 142, 205, 262, 325, 382)
lambda=.0609
ntnbf1=seq(1,1,length=length(vert_ntnb))
ntnbf2=(1-exp(-lambda*vert_ntnb))/(lambda*vert_ntnb)
ntnbf3=((1-exp(-lambda*vert_ntnb))/(lambda*vert_ntnb)-exp(-lambda*vert_ntnb))

ntnbdlreg=lm(as.numeric(NTNB[4626,])~ntnbf1+ntnbf2+ntnbf3-1)

#plot(vert_ntnb,NTNB[4626,])
#lines(vert_ntnb,fitted(ntnbdlreg))


#NTN-B discount

ntnbdiscount = bond.discount(NTNB[4626,], vert_ntnb, input.type = "spot", compounding.frequency = 1, na.rm = F)
ntnbdlreg2 <- lm(as.numeric(ntnbdiscount)~ntnbf1+ntnbf2+ntnbf3-1)
#plot(vert_ntnb,ntnbdiscount,type="l")



#NTN-B Foward

ntnbforward = bond.forward(NTNB[4626,], vert_ntnb, input.type = "spot", compounding.frequency = 1, na.rm = F)
ntnbdlreg3 <- lm(as.numeric(ntnbforward)~ntnbf1+ntnbf2+ntnbf3-1)

#plot(vert_ntnb,ntnbforward,type="l")


# Gráficos ----------------------------------------------------------------

#LTN Spot

ltn_graph <- data.frame(vert = vert_ltn, 
                         yield = as.numeric(LTN[1352,]), 
                         ns1 = fitted(ltndlreg), 
                         discount = as.numeric(ltndiscount),
                         foward = as.numeric(ltnforward),
                        ns2 = fitted(ltndlreg2),
                        ns3 = fitted(ltndlreg3))

ltn_spot <- ggplot(data = ltn_graph) +
  geom_point(aes(x = vert, y = yield), color = 'blue') +
  geom_line(aes(x = vert, y = ns1), size = 1, lineend = 'round', linejoin = 'round')+
  labs(x = "Vértices (meses)",
       y = "Taxa",
       title = "LTN Curva Spot") +
  theme_bw()
print(ltn_spot)

#LTN Discount

ltn_discount <- ggplot(data = ltn_graph) +
  geom_point(aes(x = vert, y = discount), color = 'green') +
  geom_line(aes(x = vert, y = ns2), size = 1, lineend = 'round', linejoin = 'round')+
  labs(x = "Vértices (meses)",
       y = "Taxa",
       title = "LTN Curva Descontada") +
  theme_bw()
print(ltn_discount)

#LTN Foward

ltn_foward <- ggplot(data = ltn_graph) +
  geom_point(aes(x = vert, y = foward), color = 'red') +
  geom_line(aes(x = vert, y = ns3), size = 1, lineend = 'round', linejoin = 'round')+
  labs(x = "Vértices (meses)",
       y = "Taxa",
       title = "LTN Curva Foward") +
  theme_bw()
print(ltn_foward)

#NTN-B Spot

ntnb_graph <- data.frame(vert = vert_ntnb, 
                  yield = as.numeric(NTNB[4626,]), 
                  ns1 = fitted(ntnbdlreg), 
                  discount = as.numeric(ntnbdiscount),
                  foward = as.numeric(ntnbforward),
                  ns2 = fitted(ntnbdlreg2),
                  ns3 = fitted(ntnbdlreg3))

ntnb_spot <- ggplot(data = ntnb_graph) +
  geom_point(aes(x = vert, y = yield), color = 'blue') +
  geom_line(aes(x = vert, y = ns1), size = 1, lineend = 'round', linejoin = 'round')+
  labs(x = "Vértices (meses)",
       y = "Taxa",
       title = "NTN-B Curva Spot") +
  theme_bw()
print(ntnb_spot)

#NTN-B Discount

ntnb_discount <- ggplot(data = ntnb_graph) +
  geom_point(aes(x = vert, y = discount), color = 'green') +
  geom_line(aes(x = vert, y = ns2), size = 1, lineend = 'round', linejoin = 'round')+
  labs(x = "Vértices (meses)",
       y = "Taxa",
       title = "NTN-B Curva Descontada") +
  theme_bw()
print(ntnb_discount)

#NTN-B Foward

ntnb_foward <- ggplot(data = ntnb_graph) +
  geom_point(aes(x = vert, y = foward), color = 'red') +
  geom_line(aes(x = vert, y = ns3), size = 1, lineend = 'round', linejoin = 'round')+
  labs(x = "Vértices (meses)",
       y = "Taxa",
       title = "NTN-B Curva Foward") +
  theme_bw()
print(ntnb_foward)

